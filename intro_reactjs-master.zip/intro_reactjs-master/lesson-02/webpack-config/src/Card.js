import React from 'react'

const Card = () => (
  <div>
    Card
  </div>
)

export { Card }